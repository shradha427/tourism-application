package com.example.capstone_project;

import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.capstone_project.adapters.UserBookingAdapter;
import com.example.capstone_project.models.BookingModel;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;

import java.util.ArrayList;

public class UserBookingsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private UserBookingAdapter adapter;
    private ArrayList<BookingModel> userBookings;
    private String userEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_bookings);

        recyclerView = findViewById(R.id.rvBookings);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        userBookings = new ArrayList<>();

        userEmail = FirebaseAuth.getInstance().getCurrentUser().getEmail();
        adapter = new UserBookingAdapter(userBookings);
        recyclerView.setAdapter(adapter);

        fetchUserBookings();
    }

    private void fetchUserBookings() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("BookingRequests");

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                userBookings.clear();
                for (DataSnapshot data : snapshot.getChildren()) {
                    BookingModel booking = data.getValue(BookingModel.class);
                    if (booking != null && booking.getUserEmail().equals(userEmail)) {
                        userBookings.add(booking);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UserBookingsActivity.this, "Error loading bookings", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
