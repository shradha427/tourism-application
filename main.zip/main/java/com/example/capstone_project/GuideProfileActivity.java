package com.example.capstone_project;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class GuideProfileActivity extends AppCompatActivity {

    private TextView tvName, tvEmail, tvLocation;
    private EditText phoneEditText, experienceEditText;
    private Button updateButton;

    private FirebaseAuth mAuth;
    private FirebaseDatabase db;
    private FirebaseFirestore firestore;
    private String guideId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide_profile);

        // UI Components
        tvName = findViewById(R.id.tvGuideName);
        tvEmail = findViewById(R.id.tvGuideEmail);
        tvLocation = findViewById(R.id.tvGuideLocation);
        phoneEditText = findViewById(R.id.guidePhoneEditText);
        experienceEditText = findViewById(R.id.experienceEditText);
        updateButton = findViewById(R.id.guideUpdateButton);

        // Firebase
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseDatabase.getInstance();
        firestore = FirebaseFirestore.getInstance();
        guideId = mAuth.getCurrentUser().getUid();

        // Load data
        loadRealtimeData();     // name, email, phone, location
        loadFirestoreData();    // experience

        updateButton.setOnClickListener(v -> updateFirestoreData());
    }

    private void loadRealtimeData() {
        db.getReference("Guides").child(guideId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String email = snapshot.child("email").getValue(String.class);
                    String mobile = snapshot.child("mobileNo").getValue(String.class);
                    String location = snapshot.child("location").getValue(String.class);

                    // Display email and phone
                    tvEmail.setText(email != null ? email : "N/A");
                    phoneEditText.setText(mobile != null ? mobile : "");
                    tvLocation.setText(location != null ? location : "N/A");

                    // You can derive name from email prefix or add a name field in sign-up
                    if (email != null && email.contains("@")) {
                        String name = email.substring(0, email.indexOf("@"));
                        tvName.setText(name);
                    } else {
                        tvName.setText("Guide");
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(GuideProfileActivity.this, "Failed to load profile info", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadFirestoreData() {
        firestore.collection("guides").document(guideId)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        experienceEditText.setText(documentSnapshot.getString("experience"));
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Error loading experience", Toast.LENGTH_SHORT).show()
                );
    }

    private void updateFirestoreData() {
        String phone = phoneEditText.getText().toString().trim();
        String experience = experienceEditText.getText().toString().trim();

        Map<String, Object> updatedData = new HashMap<>();
        updatedData.put("phone", phone);  // optional: sync back to Firestore
        updatedData.put("experience", experience);

        firestore.collection("guides").document(guideId)
                .set(updatedData)
                .addOnSuccessListener(aVoid ->
                        Toast.makeText(this, "Profile updated successfully!", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Update failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}
