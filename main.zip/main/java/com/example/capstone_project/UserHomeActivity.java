package com.example.capstone_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.capstone_project.fragments.BookingsFragment;
import com.example.capstone_project.fragments.MapsFragment;
import com.example.capstone_project.fragments.ProfileFragment;
import com.example.capstone_project.fragments.UserMainFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class UserHomeActivity extends AppCompatActivity {
    ImageView imageView, imageView1, imageView2, imageView3, imageView4;
    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);
        imageView = findViewById(R.id.rain);           //weather
        imageView1 = findViewById(R.id.exlpore);      // Explore
        imageView2 = findViewById(R.id.Cusines);      // Cusines
        imageView3 = findViewById(R.id.culture);
// Culture
        bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Default fragment
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, new UserMainFragment())
                .commit();

        // Bottom Navigation Listener
        bottomNavigationView.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;
            int id = item.getItemId();

            if (id == R.id.nav_home) {
                selectedFragment = new UserMainFragment();
            } else if (id == R.id.nav_maps) {
                Intent intent = new Intent(UserHomeActivity.this, MapsActivity.class);
                startActivity(intent);
                return false;
            } else if (id == R.id.nav_bookings) {
                // Navigate to UserBookingsActivity
                Intent intent = new Intent(UserHomeActivity.this, UserBookingsActivity.class);
                startActivity(intent);
                return false;  // Prevent fragment replacement
            } else if (id == R.id.nav_profile) {
                // Navigate to UserProfileActivity
                Intent intent = new Intent(UserHomeActivity.this, UserProfileActivity.class);
                startActivity(intent);
                return false;  // Prevent fragment replacement
            }

            if (selectedFragment != null) {
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, selectedFragment)
                        .commit();
            }

            return true;
        });

        imageView.setOnClickListener(v -> {
            Intent intent = new Intent(UserHomeActivity.this, WeatherActivity.class);
            startActivity(intent);
        });
        // Image Click Listeners
        imageView1.setOnClickListener(v -> {
            Intent intent = new Intent(UserHomeActivity.this, places_explore.class);
            startActivity(intent);
        });

        imageView2.setOnClickListener(v -> {
            Intent intent = new Intent(UserHomeActivity.this, food.class);
            startActivity(intent);
        });

        imageView3.setOnClickListener(v -> {
            Intent intent = new Intent(UserHomeActivity.this, culture.class);
            startActivity(intent);
        });

    }
}
