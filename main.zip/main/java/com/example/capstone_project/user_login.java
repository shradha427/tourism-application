package com.example.capstone_project;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.*;
import com.google.firebase.firestore.*;

public class user_login extends AppCompatActivity {

    private static final String TAG = "UserLogin";
    private Button button;
    private EditText usernameEditText, passwordEditText;
    private FirebaseAuth mAuth;
    private DatabaseReference databaseReference;
    private FirebaseFirestore firestore;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_login);

        mAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference("Users");
        firestore = FirebaseFirestore.getInstance();

        usernameEditText = findViewById(R.id.u_name);
        passwordEditText = findViewById(R.id.pass_key);
        button = findViewById(R.id.btnlogin);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Logging in...");

        button.setOnClickListener(v -> {
            String email = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            if (isValidInput(email, password)) {  // Now this method is defined
                checkUserInFirestore(email, password);
            }
        });
        TextView textView = findViewById(R.id.user_signin);
        textView.setOnClickListener(v -> {
            startActivity(new Intent(user_login.this, user_signin.class));
            finish();
        });
        ImageView imageView = findViewById(R.id.back_first);
        imageView.setOnClickListener(v -> {
            startActivity(new Intent(user_login.this, first_page.class));
            finish();
        });
    }

    private void checkUserInFirestore(String email, String password) {
        firestore.collection("Users").whereEqualTo("email", email).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (!queryDocumentSnapshots.isEmpty()) {
                        loginUser(email, password);
                    } else {
                        checkUserInRealtimeDatabase(email);
                    }
                });
    }

    private void checkUserInRealtimeDatabase(String email) {
        databaseReference.orderByChild("email").equalTo(email).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Toast.makeText(user_login.this, "Wrong guide are you.", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(user_login.this, "User not found.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(user_login.this, "Database error.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loginUser(String email, String password) {
        progressDialog.show();
        button.setEnabled(false);

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    progressDialog.dismiss();
                    button.setEnabled(true);

                    if (task.isSuccessful()) {
                        startActivity(new Intent(user_login.this, UserHomeActivity.class));
                        finish();
                    } else {
                        Toast.makeText(user_login.this, "Invalid email or password", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    // **Fixed: Added isValidInput Method**
    private boolean isValidInput(String email, String password) {
        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            usernameEditText.setError("Enter a valid email");
            return false;
        }
        if (password.isEmpty() || password.length() < 8) {
            passwordEditText.setError("Password must be at least 8 characters");
            return false;
        }
        return true;
    }
}

