package com.example.capstone_project;
import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.Random;

public class mobile_no extends AppCompatActivity {

    private EditText editTextPhone;
    private Button loginButton;
    private static final int SMS_PERMISSION_REQUEST = 101;
    private String generatedOtp; // Store OTP

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mobile_no);

        editTextPhone = findViewById(R.id.editTextPhone);
        loginButton = findViewById(R.id.loginbtn);

        // Request SMS Permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST);
        }

        loginButton.setOnClickListener(view -> {
            String phoneNumber = editTextPhone.getText().toString().trim();

            if (phoneNumber.isEmpty() || phoneNumber.length() != 10) {
                Toast.makeText(mobile_no.this, "Enter a valid 10-digit phone number", Toast.LENGTH_SHORT).show();
                return;
            }

            // Generate OTP
            generatedOtp = generateOTP();

            // Send OTP via SMS
            sendOTP(phoneNumber, generatedOtp);

            // Move to OTP Verification Activity
            Intent intent = new Intent(mobile_no.this, otp_verification.class);
            intent.putExtra("phone", phoneNumber);
            intent.putExtra("otp", generatedOtp); // Send OTP to next screen
            startActivity(intent);
        });
        ImageView imageView=(ImageView) findViewById(R.id.back_usign);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mobile_no.this, user_signin.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private String generateOTP() {
        Random random = new Random();
        int otp = 1000 + random.nextInt(9000); // 4-digit OTP
        return String.valueOf(otp);
    }

    private void sendOTP(String phoneNumber, String otp) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            String message = "Your OTP for Kolhapur Tourism  is: " + otp;
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "OTP sent successfully!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            showErrorDialog("Failed to send OTP. Make sure SMS permission is enabled.");
        }
    }

    private void showErrorDialog(String message) {
        new AlertDialog.Builder(this)
                .setTitle("Error")
                .setMessage(message)
                .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}