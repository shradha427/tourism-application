package com.example.capstone_project;


import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class culture extends AppCompatActivity {

    private Button Kolhapur_Cultures;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.culture);

        // Initialize the Cultures Button
        Kolhapur_Cultures = findViewById(R.id.button);

        // Array of Kolhapur culture names
        String[] cultures = {"Gudhipadwa", "Gokul Ashtami", "Ganesh Utsav",
                "Kolhapuri Chappal", "Kolhapuri Lavani", "Kolhapuri Saree"};

        // Set OnClickListener for the "Cultures" button
        Kolhapur_Cultures.setOnClickListener(v -> {
            // Log for debugging to ensure button click is registered
            Log.d("CultureSelection", "Button clicked, showing popup menu.");

            // Create a PopupMenu to show the culture names
            PopupMenu popupMenu = new PopupMenu(culture.this, Kolhapur_Cultures);

            // Add items to the PopupMenu
            for (String culture : cultures) {
                popupMenu.getMenu().add(culture);
            }

            // Set a listener to handle menu item clicks
            popupMenu.setOnMenuItemClickListener(item -> {
                // Get the selected culture name
                String selectedCulture = item.getTitle().toString();

                // Log the selected culture
                Log.d("CultureSelection", "Culture selected: " + selectedCulture);

                // Check if the selected culture is "Gudhipadwa"
                if (selectedCulture.equals("Gudhipadwa")) {
                    // Log the navigation process
                    Log.d("CultureSelection", "Navigating to Gudhipadwa page...");
                    // Navigate to the Gudhipadwa activity
                    Intent intent = new Intent(culture.this, gudhi.class);
                    startActivity(intent);
                }
                // Check if the selected culture is "Gokul Ashtami"

                else if (selectedCulture.equals("Gokul Ashtami")) {
                    // Log the navigation process
                    Log.d("CultureSelection", "Navigating to Gokul Ashtami page...");
                    // Navigate to the Gudhipadwa activity
                    Intent intent = new Intent(culture.this, gokul.class);
                    startActivity(intent);
                    // Check if the selected culture is "ganesh utsav"

                }
                // Check if the selected culture is "Ganesh Utsav"

                else if (selectedCulture.equals("Ganesh Utsav")) {
                    // Log the navigation process
                    Log.d("CultureSelection", "Navigating to Ganesh Utsav page...");
                    // Navigate to the Ganesh Utsav activity
                    Intent intent = new Intent(culture.this, ganesh.class);
                    startActivity(intent);
                }
                // Check if the selected culture is "Kolhapuri Chappal"

                else if (selectedCulture.equals("Kolhapuri Chappal")) {
                    // Log the navigation process
                    Log.d("CultureSelection", "Navigating to Kolhapuri Chappal page...");
                    // Navigate to the Kolhapuri Chappal activity
                    Intent intent = new Intent(culture.this, chappal.class);
                    startActivity(intent);
                }
                // Check if the selected culture is "Kolhapuri Lavani"

                else if (selectedCulture.equals("Kolhapuri Lavani")) {
                    // Log the navigation process
                    Log.d("CultureSelection", "Navigating to Kolhapuri Lavani page...");
                    // Navigate to the Kolhapuri Lavani activity
                    Intent intent = new Intent(culture.this, lavani.class);
                    startActivity(intent);
                }
                // Check if the selected culture is "Kolhapuri Saree"

                else if (selectedCulture.equals("Kolhapuri Saree")) {
                    // Log the navigation process
                    Log.d("CultureSelection", "Navigating to Kolhapuri Saree page...");
                    // Navigate to the Kolhapuri Saree activity
                    Intent intent = new Intent(culture.this, saree.class);
                    startActivity(intent);
                }
                else {
                    // For other selected cultures, show a Toast
                    Toast.makeText(culture.this, "Selected Culture: " + selectedCulture, Toast.LENGTH_SHORT).show();
                }
                return true;
            });

            // Show the PopupMenu
            popupMenu.show();
        });
        ImageView imageView = findViewById(R.id.backarrow);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(culture.this, UserHomeActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }
}
