package com.example.capstone_project;

import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.capstone_project.adapters.GuideAdapter;
import com.example.capstone_project.adapters.GuideBookingAdapter;
import com.example.capstone_project.models.BookingModel;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;

import java.util.ArrayList;

public class GuideBookingsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private GuideBookingAdapter adapter;
    private ArrayList<BookingModel> bookings;
    private String guideEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide_bookings);

        recyclerView = findViewById(R.id.rvBookings);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        bookings = new ArrayList<>();

        guideEmail = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        adapter = new GuideBookingAdapter(bookings, this::handleBookingAction);
        recyclerView.setAdapter(adapter);

        fetchBookings();
    }

    private void fetchBookings() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("BookingRequests");

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                bookings.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    BookingModel booking = snap.getValue(BookingModel.class);
                    if (booking != null && booking.getGuideEmail().equals(guideEmail)
                            && (booking.getStatus().equals("pending") || booking.getStatus().equals("accepted"))) {
                        bookings.add(booking);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(GuideBookingsActivity.this, "Failed to load bookings", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void handleBookingAction(String bookingId, boolean accepted) {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("BookingRequests").child(bookingId);

        String newStatus = accepted ? "accepted" : "cancelled";

        ref.child("status").setValue(newStatus).addOnSuccessListener(unused -> {
            if (!accepted) {
                ref.child("message").setValue("Guide is not available");
            }
            Toast.makeText(this, accepted ? "Booking Accepted" : "Booking Cancelled", Toast.LENGTH_SHORT).show();
        }).addOnFailureListener(e -> {
            Toast.makeText(this, "Failed to update booking status", Toast.LENGTH_SHORT).show();
        });
    }

}