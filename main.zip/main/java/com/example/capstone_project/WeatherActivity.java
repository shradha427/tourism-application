package com.example.capstone_project;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.capstone_project.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class WeatherActivity extends AppCompatActivity {

    private static final int LOCATION_PERMISSION_CODE = 101;
    private FusedLocationProviderClient fusedLocationClient;
    private TextView weatherText;

    private String API_KEY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        API_KEY = getString(R.string.wether_key);

        getLocation();
    }

    private void getLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_CODE);
            return;
        }

        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, location -> {
                    if (location != null) {
                        fetchWeather(location);
                    }
                });
    }

    private void fetchWeather(Location location) {
        new Thread(() -> {
            try {
                // Current Weather
                String weatherUrl = "https://api.openweathermap.org/data/2.5/weather?lat=" +
                        location.getLatitude() + "&lon=" + location.getLongitude() +
                        "&units=metric&appid=" + API_KEY;

                // Forecast URL (every 3 hours for 5 days)
                String forecastUrl = "https://api.openweathermap.org/data/2.5/forecast?lat=" +
                        location.getLatitude() + "&lon=" + location.getLongitude() +
                        "&units=metric&appid=" + API_KEY;

                // Fetch current weather
                JSONObject weatherJson = new JSONObject(readFromUrl(weatherUrl));
                String city = weatherJson.getString("name");
                String weather = weatherJson.getJSONArray("weather").getJSONObject(0).getString("description");
                String icon = weatherJson.getJSONArray("weather").getJSONObject(0).getString("icon");
                String temp = weatherJson.getJSONObject("main").getString("temp");

                runOnUiThread(() -> {
                    TextView cityText = findViewById(R.id.cityText);
                    TextView descriptionText = findViewById(R.id.descriptionText);
                    TextView tempText = findViewById(R.id.tempText);
                    ImageView weatherIcon = findViewById(R.id.weatherIcon);

                    cityText.setText(city);
                    descriptionText.setText(weather);
                    tempText.setText(temp + "°C");

                    Glide.with(this)
                            .load("https://openweathermap.org/img/wn/" + icon + "@2x.png")
                            .into(weatherIcon);

                    Glide.with(this)
                            .load("https://openweathermap.org/img/wn/" + icon + "@2x.png")
                            .into(weatherIcon);
                });

                // Fetch 5-day forecast
                JSONObject forecastJson = new JSONObject(readFromUrl(forecastUrl));
                JSONArray list = forecastJson.getJSONArray("list");
                List<ForecastItem> forecastItems = new ArrayList<>();

                for (int i = 0; i < list.length(); i += 8) { // every 24 hours
                    JSONObject obj = list.getJSONObject(i);
                    String day = obj.getString("dt_txt").split(" ")[0];
                    String tempF = obj.getJSONObject("main").getString("temp");
                    String iconF = obj.getJSONArray("weather").getJSONObject(0).getString("icon");
                    forecastItems.add(new ForecastItem(day, tempF, iconF));
                }

                runOnUiThread(() -> {
                    RecyclerView forecastRecycler = findViewById(R.id.forecastRecycler);
                    forecastRecycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
                    forecastRecycler.setAdapter(new ForecastAdapter(forecastItems));
                });


            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() ->
                        Toast.makeText(this, "Error fetching weather", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private String readFromUrl(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.connect();
        InputStream stream = conn.getInputStream();
        Scanner scanner = new Scanner(stream).useDelimiter("\\A");
        return scanner.hasNext() ? scanner.next() : "";
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_CODE && grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            getLocation();
        } else {
            Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
        }
    }
}
