package com.example.capstone_project;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.capstone_project.adapters.GuideAdapter;
import com.example.capstone_project.models.BookingModel;
import com.example.capstone_project.models.GuideModel;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

public class availability_bookings extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ArrayList<GuideModel> guideList;
    private GuideAdapter adapter;
    private DatabaseReference dbRef;
    private String userEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.availability_bookings);

        recyclerView = findViewById(R.id.recyclerAvailableGuides);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        guideList = new ArrayList<>();
        userEmail = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        adapter = new GuideAdapter(guideList, this::onBookClicked);
        recyclerView.setAdapter(adapter);

        dbRef = FirebaseDatabase.getInstance().getReference("Guides");
        loadGuides();
    }

    private void loadGuides() {
        dbRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                guideList.clear();
                for (DataSnapshot data : snapshot.getChildren()) {
                    String email = data.child("email").getValue(String.class);
                    String phone = data.child("mobileNo").getValue(String.class);
                    String location = data.child("location").getValue(String.class);

                    GuideModel guide = new GuideModel(email, phone, location);

                    checkGuideAvailability(guide);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void checkGuideAvailability(GuideModel guide) {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("BookingRequests");

        ref.orderByChild("guideEmail").equalTo(guide.getEmail()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                boolean isBusy = false;

                for (DataSnapshot snap : snapshot.getChildren()) {
                    BookingModel booking = snap.getValue(BookingModel.class);
                    if (booking != null && booking.getStatus().equals("accepted")) {
                        String datetimeStr = booking.getDate() + " " + booking.getTime();
                        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
                        try {
                            Date endTime = sdf.parse(datetimeStr);
                            if (endTime != null && endTime.after(new Date())) {
                                isBusy = true;
                                break;
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }

                if (!isBusy) {
                    guideList.add(guide);
                    adapter.notifyDataSetChanged();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void onBookClicked(GuideModel guide) {
        final Calendar calendar = Calendar.getInstance();

        // Date picker
        DatePickerDialog datePicker = new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> {

                    // Time picker after date selected
                    TimePickerDialog timePicker = new TimePickerDialog(this,
                            (timeView, hourOfDay, minute) -> {
                                String date = dayOfMonth + "/" + (month + 1) + "/" + year;
                                String time = String.format("%02d:%02d", hourOfDay, minute);
                                sendBookingRequest(guide, date, time);
                            },
                            calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false);
                    timePicker.show();

                },
                calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));

        // 🔒 Prevent selection of past dates
        datePicker.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        datePicker.show();
    }


    private void sendBookingRequest(GuideModel guide, String date, String time) {
        String bookingId = UUID.randomUUID().toString();

        BookingModel booking = new BookingModel(
                bookingId,
                guide.getEmail(),
                userEmail,
                date,
                time,
                "pending"
        );

        FirebaseDatabase.getInstance().getReference("BookingRequests")
                .child(bookingId)
                .setValue(booking)
                .addOnSuccessListener(unused -> Toast.makeText(this, "Booking request sent", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e -> Toast.makeText(this, "Failed to send request", Toast.LENGTH_SHORT).show());
    }
}