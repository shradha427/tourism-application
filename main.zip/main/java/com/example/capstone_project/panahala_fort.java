package com.example.capstone_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class panahala_fort extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the correct layout for Panhala Fort Activity
        setContentView(R.layout.panhala_fort);
        Button button=(Button)findViewById(R.id.g_panhala);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(panahala_fort.this, availability_bookings.class);
                startActivity(intent);
                finish();
            }
        });
        ImageView imageView = findViewById(R.id.backArrow4);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(panahala_fort.this, places_explore.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
