package com.example.capstone_project;

import android.os.AsyncTask;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class PlaceSearchTask extends AsyncTask<String, Void, String> {

    private final GoogleMap mMap;

    public PlaceSearchTask(GoogleMap map) {
        this.mMap = map;
    }

    @Override
    protected String doInBackground(String... urls) {
        StringBuilder data = new StringBuilder();
        try {
            URL url = new URL(urls[0]);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            InputStream stream = conn.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
            String line;
            while ((line = reader.readLine()) != null) {
                data.append(line);
            }
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data.toString();
    }

    @Override
    protected void onPostExecute(String result) {
        try {
            JSONObject jsonObject = new JSONObject(result);
            JSONArray results = jsonObject.getJSONArray("results");

            for (int i = 0; i < results.length(); i++) {
                JSONObject place = results.getJSONObject(i);
                JSONObject geometry = place.getJSONObject("geometry").getJSONObject("location");
                String name = place.getString("name");
                LatLng latLng = new LatLng(geometry.getDouble("lat"), geometry.getDouble("lng"));
                mMap.addMarker(new MarkerOptions().position(latLng).title(name));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
