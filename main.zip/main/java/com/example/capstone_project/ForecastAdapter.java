package com.example.capstone_project;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

public class ForecastAdapter extends RecyclerView.Adapter<ForecastAdapter.ViewHolder> {
    private final List<ForecastItem> forecastList;

    public ForecastAdapter(List<ForecastItem> forecastList) {
        this.forecastList = forecastList;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView dayText, tempText;
        ImageView iconImage;

        public ViewHolder(View itemView) {
            super(itemView);
            dayText = itemView.findViewById(R.id.dayText);
            tempText = itemView.findViewById(R.id.tempText);
            iconImage = itemView.findViewById(R.id.iconImage);
        }
    }

    @NonNull
    @Override
    public ForecastAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.forecast_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ForecastAdapter.ViewHolder holder, int position) {
        ForecastItem item = forecastList.get(position);
        holder.dayText.setText(item.getDay());
        holder.tempText.setText(item.getTemp() + "°C");
        Glide.with(holder.iconImage.getContext())
                .load("https://openweathermap.org/img/wn/" + item.getIcon() + "@2x.png")
                .into(holder.iconImage);
    }

    @Override
    public int getItemCount() {
        return forecastList.size();
    }
}
