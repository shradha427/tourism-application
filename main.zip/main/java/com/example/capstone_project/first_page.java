package com.example.capstone_project;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;


import androidx.appcompat.app.AppCompatActivity;

public class first_page extends AppCompatActivity {
    public Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.first_page);
        button=(Button)findViewById(R.id.btn2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(first_page.this, user_login.class);
                startActivity(intent);
                finish();
            }
        });
        Button bt2 = findViewById(R.id.btn1);
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(first_page.this, guide_login.class);
                startActivity(intent);
                finish();
            }
        });



    }

}


