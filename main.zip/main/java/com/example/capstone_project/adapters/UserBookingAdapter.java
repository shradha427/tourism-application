package com.example.capstone_project.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.capstone_project.R;
import com.example.capstone_project.models.BookingModel;

import java.util.ArrayList;

public class UserBookingAdapter extends RecyclerView.Adapter<UserBookingAdapter.ViewHolder> {

    private ArrayList<BookingModel> bookings;

    public UserBookingAdapter(ArrayList<BookingModel> bookings) {
        this.bookings = bookings;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user_booking, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BookingModel booking = bookings.get(position);

        holder.tvGuide.setText("Guide: " + booking.getGuideEmail());
        holder.tvDate.setText("Date: " + booking.getDate());
        holder.tvTime.setText("Time: " + booking.getTime());
        holder.tvStatus.setText("Status: " + booking.getStatus());

        if (booking.getMessage() != null && !booking.getMessage().isEmpty()) {
            holder.tvMessage.setVisibility(View.VISIBLE);
            holder.tvMessage.setText("Note: " + booking.getMessage());
        } else {
            holder.tvMessage.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return bookings.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvGuide, tvDate, tvTime, tvStatus, tvMessage;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvGuide = itemView.findViewById(R.id.tvGuide);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvTime = itemView.findViewById(R.id.tvTime);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            tvMessage = itemView.findViewById(R.id.tvMessage);
        }
    }
}
