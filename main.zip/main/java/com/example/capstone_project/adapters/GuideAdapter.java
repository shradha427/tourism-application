package com.example.capstone_project.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.capstone_project.R;
import com.example.capstone_project.models.GuideModel;

import java.util.List;

public class GuideAdapter extends RecyclerView.Adapter<GuideAdapter.ViewHolder> {

    private final List<GuideModel> guideList;
    private final OnBookClickListener listener;

    public interface OnBookClickListener {
        void onBookClicked(GuideModel guide);
    }

    public GuideAdapter(List<GuideModel> guideList, OnBookClickListener listener) {
        this.guideList = guideList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_guide, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        GuideModel guide = guideList.get(position);
        holder.tvEmail.setText("Email: " + guide.getEmail());
        holder.tvPhone.setText("Phone: " + guide.getPhone());
        holder.tvLocation.setText("Location: " + guide.getLocation());

        holder.btnBook.setOnClickListener(v -> listener.onBookClicked(guide));
    }

    @Override
    public int getItemCount() {
        return guideList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvEmail, tvPhone, tvLocation;
        Button btnBook;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvEmail = itemView.findViewById(R.id.tvGuideEmail);
            tvPhone = itemView.findViewById(R.id.tvGuidePhone);
            tvLocation = itemView.findViewById(R.id.tvGuideLocation);
            btnBook = itemView.findViewById(R.id.btnBookGuide);
        }
    }
}
