package com.example.capstone_project.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.capstone_project.R;
import com.example.capstone_project.models.Feedback;

import java.util.List;

public class FeedBackAdapter extends RecyclerView.Adapter<FeedBackAdapter.FeedbackViewHolder> {
    private List<Feedback> feedbackList;

    public FeedBackAdapter(List<Feedback> feedbackList) {
        this.feedbackList = feedbackList;
    }

    public static class FeedbackViewHolder extends RecyclerView.ViewHolder {
        TextView feedbackText;

        public FeedbackViewHolder(View itemView) {
            super(itemView);
            feedbackText = itemView.findViewById(R.id.feedbackText);
        }
    }

    @Override
    public FeedbackViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_feedback, parent, false);
        return new FeedbackViewHolder(view);
    }

    @Override
    public void onBindViewHolder(FeedbackViewHolder holder, int position) {
        holder.feedbackText.setText(feedbackList.get(position).getFeedback());
    }

    @Override
    public int getItemCount() {
        return feedbackList.size();
    }
}

