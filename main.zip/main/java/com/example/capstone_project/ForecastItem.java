package com.example.capstone_project;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ForecastItem {
    private final String date;
    private final String day;
    private final String temp;
    private final String icon;

    public ForecastItem(String date, String temp, String icon) {
        this.date = date;
        this.day = getDayName(date); // Automatically compute day name from date
        this.temp = temp;
        this.icon = icon;
    }

    private String getDayName(String dateStr) {
        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.getDefault());
        try {
            Date date = inputFormat.parse(dateStr);
            return dayFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return "Unknown";
        }
    }

    public String getDate() { return date; }
    public String getDay() { return day; }
    public String getTemp() { return temp; }
    public String getIcon() { return icon; }
}
