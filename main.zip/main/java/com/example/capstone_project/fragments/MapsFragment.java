package com.example.capstone_project.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.capstone_project.R;
import com.example.capstone_project.MapsActivity;

public class MapsFragment extends Fragment {
    public MapsFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_maps, container, false);

        // Launch MapsActivity directly
        startActivity(new Intent(getContext(), MapsActivity.class));
        return view;
    }
}
