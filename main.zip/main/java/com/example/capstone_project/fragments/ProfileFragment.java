package com.example.capstone_project.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.capstone_project.R;
public class ProfileFragment extends Fragment {

    Button btnGiveFeedback;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        btnGiveFeedback = view.findViewById(R.id.btn_give_feedback);

        btnGiveFeedback.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), com.example.capstone_project.UserHomeActivity.class);
            startActivity(intent);
        });

        return view;
    }
}
