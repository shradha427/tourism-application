package com.example.capstone_project;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class otp_verification extends AppCompatActivity {
    Button button1;
    private Button button;
    private TextView tvResendOTP;
    private Button btnVerifyOTP;
    private EditText etOtp1, etOtp2, etOtp3, etOtp4;
    private CountDownTimer countDownTimer;
    private static final long RESEND_TIME = 30000; // 30 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.otp_verification);

        // Initialize UI Components
        tvResendOTP = findViewById(R.id.tv_resend_otp);
        btnVerifyOTP = findViewById(R.id.btn_verify_otp);
        etOtp1 = findViewById(R.id.et_otp_1);
        etOtp2 = findViewById(R.id.et_otp_2);
        etOtp3 = findViewById(R.id.et_otp_3);
        etOtp4 = findViewById(R.id.et_otp_4);

        button1=(Button)findViewById(R.id.btn_verify_otp);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(otp_verification.this,UserHomeActivity.class);
                startActivity(intent);
                finish();
            }
        });
        // Start the timer initially
        startResendTimer();

        // Click listener for Resend OTP
        tvResendOTP.setOnClickListener(v -> {
            resendOTP();
        });

        ImageView imageView=(ImageView) findViewById(R.id.back_mobile);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(otp_verification.this, mobile_no.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void startResendTimer() {
        tvResendOTP.setEnabled(false);
        countDownTimer = new CountDownTimer(RESEND_TIME, 1000) {
            public void onTick(long millisUntilFinished) {
                tvResendOTP.setText("Resend in " + (millisUntilFinished / 1000) + "s");
            }

            public void onFinish() {
                tvResendOTP.setText("Resend OTP");
                tvResendOTP.setEnabled(true);
            }
        }.start();
    }

    private void resendOTP() {
        tvResendOTP.setEnabled(false);
        tvResendOTP.setText("Sending OTP...");

        // Here, trigger the API call to resend OTP via MSG91
        // For now, simulate OTP sending delay
        new android.os.Handler().postDelayed(() -> {
            startResendTimer(); // Restart the countdown
        }, 2000); // Simulating a 2-second delay
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
    }
}