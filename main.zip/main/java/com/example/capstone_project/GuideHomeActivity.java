package com.example.capstone_project;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.capstone_project.adapters.FeedBackAdapter;
import com.example.capstone_project.fragments.GuideMainFragment;
import com.example.capstone_project.models.Feedback;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.List;

public class GuideHomeActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide_home);

        bottomNavigationView = findViewById(R.id.bottom_navigation_guide);

        // Load default fragment
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container_guide, new GuideMainFragment())
                .commit();

        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_home_guide) {
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container_guide, new GuideMainFragment())
                        .commit();

            } else if (id == R.id.nav_bookings_guide) {
                Intent intent = new Intent(GuideHomeActivity.this, GuideBookingsActivity.class);
                startActivity(intent);

            } else if (id == R.id.nav_profile_guide) {
                Intent intent = new Intent(GuideHomeActivity.this, GuideProfileActivity.class);
                startActivity(intent);
            }

            return true;
        });
        RecyclerView feedbackRecyclerView = findViewById(R.id.feedbackRecyclerView);
        feedbackRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<Feedback> feedbackList = new ArrayList<>();
        FeedBackAdapter adapter = new FeedBackAdapter(feedbackList);
        feedbackRecyclerView.setAdapter(adapter);

        FirebaseFirestore.getInstance().collection("Feedbacks")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .addSnapshotListener((value, error) -> {
                    feedbackList.clear();
                    if (value != null) {
                        for (DocumentSnapshot doc : value.getDocuments()) {
                            Feedback feedback = doc.toObject(Feedback.class);
                            feedbackList.add(feedback);
                        }
                        adapter.notifyDataSetChanged();
                    }
                });

    }

}
