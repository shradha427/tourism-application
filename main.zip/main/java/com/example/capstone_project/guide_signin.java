package com.example.capstone_project;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.Arrays;
import java.util.List;

public class guide_signin extends AppCompatActivity {

    private static final String TAG = "GuideSignIn";
    private EditText usernameEditText, passwordEditText, mobileNoEditText;
    private Spinner locationSpinner;
    private Button button;
    private FirebaseAuth mAuth;
    private DatabaseReference databaseReference;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guide_signin);

        // Initialize Firebase Authentication and Database
        mAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference("Guides");

        // Initialize views
        usernameEditText = findViewById(R.id.g_username);
        passwordEditText = findViewById(R.id.g_password);
        mobileNoEditText = findViewById(R.id.g_Phone);
        locationSpinner = findViewById(R.id.loc_spinner);
        button = findViewById(R.id.g_signin);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Registering...");

        // Populate Spinner with locations
        List<String> locations = Arrays.asList(
                "Pavangad Fort", "Rangana Fort", "Vishalgad Fort", "Panhala Fort",
                "Samangad Fort", "Bhudargad Fort", "Kalamwadi Waterfall", "Rautwadi Waterfall",
                "Toraskarwadi Waterfall", "Mahalaxmi Temple", "Jotiba Temple", "Balumama Temple"
        );
        locations.sort(String::compareToIgnoreCase);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, locations);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        locationSpinner.setAdapter(adapter);

        // Sign-up button listener
        button.setOnClickListener(v -> {
            String email = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();
            String mobileNo = mobileNoEditText.getText().toString().trim();
            String selectedLocation = locationSpinner.getSelectedItem().toString();

            if (isValidInput(email, password, mobileNo)) {
                registerGuide(email, password, mobileNo, selectedLocation);
            }
        });

        // Back button
        ImageView imageView = findViewById(R.id.back_glog);
        imageView.setOnClickListener(v -> {
            Intent intent = new Intent(guide_signin.this, guide_login.class);
            startActivity(intent);
            finish();
        });
    }

    private void registerGuide(String email, String password, String mobileNo, String location) {
        progressDialog.show();
        button.setEnabled(false);

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    progressDialog.dismiss();
                    button.setEnabled(true);

                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            String userId = user.getUid();
                            Guide guide = new Guide(email, mobileNo, location);
                            databaseReference.child(userId).setValue(guide)
                                    .addOnCompleteListener(dbTask -> {
                                        if (dbTask.isSuccessful()) {
                                            Toast.makeText(guide_signin.this, "Sign Up Successful", Toast.LENGTH_SHORT).show();
                                            startActivity(new Intent(guide_signin.this, GuideHomeActivity.class));
                                            finish();
                                        } else {
                                            Toast.makeText(guide_signin.this, "Database Error", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                        }
                    } else {
                        Toast.makeText(guide_signin.this, "Sign up failed: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    private boolean isValidInput(String email, String password, String mobileNo) {
        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            usernameEditText.setError("Enter a valid email");
            return false;
        }
        if (password.isEmpty() || password.length() < 8) {
            passwordEditText.setError("Password must be at least 8 characters");
            return false;
        }
        if (mobileNo.isEmpty() || mobileNo.length() != 10 || !mobileNo.matches("\\d+")) {
            mobileNoEditText.setError("Mobile number must be 10 digits");
            return false;
        }
        return true;
    }

    public static class Guide {
        public String email, mobileNo, location;

        public Guide() {}

        public Guide(String email, String mobileNo, String location) {
            this.email = email;
            this.mobileNo = mobileNo;
            this.location = location;
        }
    }
}
