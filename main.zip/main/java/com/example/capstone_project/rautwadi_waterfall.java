package com.example.capstone_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class rautwadi_waterfall extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rahutwadi_waterfall);
        Button button=(Button)findViewById(R.id.g_rahutwadi);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(rautwadi_waterfall.this, availability_bookings.class);
                startActivity(intent);
                finish();
            }
        });
        ImageView imageView = findViewById(R.id.backArrow6);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(rautwadi_waterfall.this, places_explore.class);
                startActivity(intent);
                finish();
            }
        });
    }
}

