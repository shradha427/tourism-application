package com.example.capstone_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class toraskarwadi_waterfall extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.toraskarwadi_waterfall);
        Button button=(Button)findViewById(R.id.g_toraskarwadi);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(toraskarwadi_waterfall.this, availability_bookings.class);
                startActivity(intent);
                finish();
            }
        });
        ImageView imageView = findViewById(R.id.backArrow9);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(toraskarwadi_waterfall.this, places_explore.class);
                startActivity(intent);
                finish();
            }
        });

    }
}
