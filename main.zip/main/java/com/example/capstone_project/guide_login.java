package com.example.capstone_project;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import androidx.appcompat.app.AlertDialog;

public class guide_login extends AppCompatActivity {

    private static final String TAG = "GuideLogin";
    private EditText usernameEditText, passwordEditText;
    private Button loginButton;
    private FirebaseAuth mAuth;
    private DatabaseReference databaseReference;
    private FirebaseFirestore firestore;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guide_login);

        // Initialize Firebase Auth, Firestore, and Database Reference
        mAuth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference("Guides");

        // Initialize views
        usernameEditText = findViewById(R.id.btn_username);
        passwordEditText = findViewById(R.id.btn_password);
        loginButton = findViewById(R.id.btn_signin);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Logging in...");

        // Set up the login button click listener
        loginButton.setOnClickListener(v -> {
            String email = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            if (isValidInput(email, password)) {
                checkGuideInRealtimeDatabase(email, password);
            }
        });

        // Redirect to sign-up page
        TextView textView = findViewById(R.id.guide_sign);
        textView.setOnClickListener(v -> {
            startActivity(new Intent(guide_login.this, guide_signin.class));
            finish();
        });

        // Back button
        ImageView imageView = findViewById(R.id.back_fst);
        imageView.setOnClickListener(v -> {
            startActivity(new Intent(guide_login.this, first_page.class));
            finish();
        });
    }

    private boolean isValidInput(String email, String password) {
        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            usernameEditText.setError("Enter a valid email");
            return false;
        }
        if (password.isEmpty() || password.length() < 8) {
            passwordEditText.setError("Password must be at least 8 characters");
            return false;
        }
        return true;
    }

    // Check if guide exists in Realtime Database
    private void checkGuideInRealtimeDatabase(String email, String password) {
        databaseReference.orderByChild("email").equalTo(email).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    loginGuide(email, password);
                } else {
                    checkGuideInFirestore(email);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Database error: " + error.getMessage());
                Toast.makeText(guide_login.this, "Database error. Try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // If the guide exists in Firestore, they are not valid for guide login
    private void checkGuideInFirestore(String email) {
        firestore.collection("Guides").whereEqualTo("email", email).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (!queryDocumentSnapshots.isEmpty()) {
                        Toast.makeText(guide_login.this, "Wrong user.", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(guide_login.this, "User not found.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    // Firebase authentication method
    private void loginGuide(String email, String password) {
        progressDialog.show();
        loginButton.setEnabled(false);

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    progressDialog.dismiss();
                    loginButton.setEnabled(true);

                    if (task.isSuccessful()) {
                        startActivity(new Intent(guide_login.this, GuideHomeActivity.class));
                        finish();
                    } else {
                        Toast.makeText(guide_login.this, "Invalid email or password", Toast.LENGTH_SHORT).show();
                    }
                });
    }



}
