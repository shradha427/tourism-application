package com.example.capstone_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class places_explore extends AppCompatActivity {

    private Button Kolhapur_Forts, Kolhapur_Waterfall,Kolhapur_Temple;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.places_explore);

        // Initialize UI components
        Kolhapur_Forts = findViewById(R.id.button);
        Kolhapur_Waterfall = findViewById(R.id.button2);
        Kolhapur_Temple = findViewById(R.id.button3); // The Kolhapur Waterfall button

        // Array of Kolhapur Fort names
        String[] forts = {"Pavangad Fort", "Rangana Fort", "Vishalgad Fort",
                "Panhala Fort", "Samangad Fort", "Bhudargad Fort"};

        // Array of Kolhapur Waterfalls names
        String[] waterfalls = {"Kalamwadi Waterfall", "Rautwadi Waterfall", "Toraskarwadi Waterfall"};
        // Array of Kolhapur Temples names
        String[] temples = {"Mahalaxmi Temple", "Jotiba Temple", "Balumama Temple"};



        // Set OnClickListener for the Kolhapur Waterfall button
        Kolhapur_Temple.setOnClickListener(v -> {
            // Create a PopupMenu for waterfalls when "Kolhapur Waterfall" is clicked
            PopupMenu popupMenu = new PopupMenu(places_explore.this, Kolhapur_Temple);

            // Add items to the PopupMenu
            for (String waterfall : temples) {
                popupMenu.getMenu().add(waterfall);
            }

            // Set a listener for item selection
            popupMenu.setOnMenuItemClickListener(item -> {
                // Handle item selection
                String selectedTemple = item.getTitle().toString();

                // If "Balumama Temple" is selected, navigate to balumama_templeActivity
                if (selectedTemple.equals("Balumama Temple")) {
                    Intent intent = new Intent(places_explore.this, balumama_temple.class);
                    startActivity(intent);
                }
                // If "Jotiba Temple" is selected, navigate to jotiba_templeActivity
                else if (selectedTemple.equals("Jotiba Temple")) {
                    Intent intent = new Intent(places_explore.this, jotiba_temple.class);
                    startActivity(intent);
                }
                // If "Mahalaxmi Temple" is selected, navigate to mahalaxmi_templeActivity
                else if (selectedTemple.equals("Mahalaxmi Temple")) {
                    Intent intent = new Intent(places_explore.this, mahalaxmi_temple.class);
                    startActivity(intent);
                }
                // For any other waterfall, show a Toast with the selected waterfall
                else {
                    Toast.makeText(places_explore.this, "Selected Temple: " + selectedTemple, Toast.LENGTH_SHORT).show();
                }
                return true;
            });

            // Show the PopupMenu
            popupMenu.show();
        });



        // Set OnClickListener for the Kolhapur Waterfall button
        Kolhapur_Waterfall.setOnClickListener(v -> {
            // Create a PopupMenu for waterfalls when "Kolhapur Waterfall" is clicked
            PopupMenu popupMenu = new PopupMenu(places_explore.this, Kolhapur_Waterfall);

            // Add items to the PopupMenu
            for (String waterfall : waterfalls) {
                popupMenu.getMenu().add(waterfall);
            }

            // Set a listener for item selection
            popupMenu.setOnMenuItemClickListener(item -> {
                // Handle item selection
                String selectedWaterfall = item.getTitle().toString();

                // If "Kalamwadi Waterfall" is selected, navigate to kalamwadi_waterfallActivity
                if (selectedWaterfall.equals("Kalamwadi Waterfall")) {
                    Intent intent = new Intent(places_explore.this, kalamwadi_waterfall.class);
                    startActivity(intent);
                }
                // If "Rautwadi Waterfall" is selected, navigate to rautwadi_waterfallActivity
                if (selectedWaterfall.equals("Rautwadi Waterfall")) {
                    Intent intent = new Intent(places_explore.this, rautwadi_waterfall.class);
                    startActivity(intent);
                }
                // If "Toraskarwadi Waterfall" is selected, navigate to rautwadi_waterfallActivity
                else if (selectedWaterfall.equals("Toraskarwadi Waterfall")) {
                    Intent intent = new Intent(places_explore.this, toraskarwadi_waterfall.class);
                    startActivity(intent);
                }
                // For any other waterfall, show a Toast with the selected waterfall
                else {
                    Toast.makeText(places_explore.this, "Selected Waterfall: " + selectedWaterfall, Toast.LENGTH_SHORT).show();
                }
                return true;
            });

            // Show the PopupMenu
            popupMenu.show();
        });

        // Set OnClickListener for the Kolhapur Forts button
        Kolhapur_Forts.setOnClickListener(v -> {
            // Create a PopupMenu when the button is clicked
            PopupMenu popupMenu = new PopupMenu(places_explore.this, Kolhapur_Forts);

            // Add items to the PopupMenu
            for (String fort : forts) {
                popupMenu.getMenu().add(fort);
            }

            // Set a listener for item selection
            popupMenu.setOnMenuItemClickListener(item -> {
                // Handle item selection
                String selectedFort = item.getTitle().toString();

                // If "Pavangad Fort" is selected, navigate to pavangad_fortActivity
                if (selectedFort.equals("Pavangad Fort")) {
                    Intent intent = new Intent(places_explore.this, pavangad_fort.class);
                    startActivity(intent);
                }
                // If "Rangana Fort" is selected, navigate to rangana_fortActivity
                else if (selectedFort.equals("Rangana Fort")) {
                    Intent intent = new Intent(places_explore.this, rangana_fort.class);
                    startActivity(intent);
                }
                // If "Panhala Fort" is selected, navigate to panahala_fortActivity
                else if (selectedFort.equals("Panhala Fort")) {
                    Intent intent = new Intent(places_explore.this, panahala_fort.class);
                    startActivity(intent);
                }
                // If "Samangad Fort" is selected, navigate to samangad_fortActivity
                else if (selectedFort.equals("Samangad Fort")) {
                    Intent intent = new Intent(places_explore.this, samangad_fort.class);
                    startActivity(intent);
                }
                // If "Bhudargad Fort" is selected, navigate to bhudargad_fortActivity
                else if (selectedFort.equals("Bhudargad Fort")) {
                    Intent intent = new Intent(places_explore.this, bhudargad_fort.class);
                    startActivity(intent);
                }
                // If "Vishalgad Fort" is selected, navigate to vishalgad_fortActivity
                else if (selectedFort.equals("Vishalgad Fort")) {
                    Intent intent = new Intent(places_explore.this, vishalgad_fort.class);
                    startActivity(intent);
                }
                // For any other fort, show a Toast with the selected fort
                else {
                    Toast.makeText(places_explore.this, "Selected Fort: " + selectedFort, Toast.LENGTH_SHORT).show();
                }
                return true;
            });

            // Show the PopupMenu
            popupMenu.show();
        });
        ImageView imageView = findViewById(R.id.backArrow);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(places_explore.this,UserHomeActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }
}
