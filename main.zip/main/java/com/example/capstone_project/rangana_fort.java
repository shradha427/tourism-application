package com.example.capstone_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class rangana_fort extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rangana_fort);  // Set the layout for the Hello World page
        Button button=(Button)findViewById(R.id.g_rangana);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(rangana_fort.this, availability_bookings.class);
                startActivity(intent);
                finish();
            }
        });
        ImageView imageView = findViewById(R.id.backArrow7);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(rangana_fort.this, places_explore.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
