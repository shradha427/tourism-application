package com.example.capstone_project;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class food extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.food);

        Button vegButton = findViewById(R.id.button);

        vegButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the VegFoodListActivity
                Intent intent = new Intent(food.this, vegfood.class);
                startActivity(intent);
            }
        });
        Button bt2 = findViewById(R.id.non);
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(food.this, nonveg.class);
                startActivity(intent);
                finish();
            }
        });
        ImageView imageView = findViewById(R.id.backArrow3);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(food.this, UserHomeActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }
}
