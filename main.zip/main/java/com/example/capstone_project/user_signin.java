package com.example.capstone_project;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class user_signin extends AppCompatActivity {

    private static final String TAG = "UserSignIn";  // Debugging Tag

    private EditText usernameEditText, passwordEditText, nameEditText;
    private Button button;
    private FirebaseAuth mAuth;
    private FirebaseFirestore firestore;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_signin);

        // Initialize Firebase Authentication and Firestore
        mAuth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();

        // Initialize views
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        nameEditText = findViewById(R.id.name); // Fixed: Properly initialized
        button = findViewById(R.id.btnsignin);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Registering...");

        // Sign-up button listener
        button.setOnClickListener(v -> {
            String email = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();
            String name = nameEditText.getText().toString().trim();

            if (isValidInput(email, password, name)) {
                registerUser(email, password, name);
            }
        });

        // Back button to guide login
        ImageView imageView = findViewById(R.id.back_ulog);
        imageView.setOnClickListener(v -> {
            Intent intent = new Intent(user_signin.this, user_login.class);
            startActivity(intent);
            finish();
        });
    }

    // Firebase registration method with Firestore integration
    private void registerUser(String email, String password, String name) {
        progressDialog.show();
        button.setEnabled(false);  // Prevent duplicate clicks

        Log.d(TAG, "Starting registration for: " + email);

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    progressDialog.dismiss();
                    button.setEnabled(true);  // Re-enable button

                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            String userId = user.getUid();
                            Log.d(TAG, "User registered successfully: " + userId);

                            // Store additional user details in Firestore
                            Map<String, Object> userData = new HashMap<>();
                            userData.put("email", email);
                            userData.put("name", name);  // Save name in Firestore

                            firestore.collection("Users").document(userId).set(userData)
                                    .addOnCompleteListener(dbTask -> {
                                        if (dbTask.isSuccessful()) {
                                            Log.d(TAG, "User data stored successfully in Firestore.");
                                            Toast.makeText(user_signin.this, "Sign Up Successful", Toast.LENGTH_SHORT).show();

                                            // Navigate to the next activity
                                            Intent intent = new Intent(user_signin.this, mobile_no.class);
                                            startActivity(intent);
                                            finish();
                                        } else {
                                            Log.e(TAG, "Firestore Error: " + dbTask.getException());
                                            Toast.makeText(user_signin.this, "Database Error", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                        } else {
                            Log.e(TAG, "Error: User object is null after registration.");
                            Toast.makeText(user_signin.this, "Error: User not found after registration.", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Exception exception = task.getException();
                        if (exception != null) {
                            Log.e(TAG, "Authentication Failed: " + exception.getMessage(), exception);
                            handleAuthError(exception.getMessage());
                        }
                    }
                });
    }

    // Handle Firebase authentication errors
    private void handleAuthError(String errorMessage) {
        if (errorMessage.contains("email address is already in use")) {
            usernameEditText.setError("Email already registered. Try another.");
        } else if (errorMessage.contains("The given password is invalid")) {
            passwordEditText.setError("Weak password. Must be at least 8 characters.");
        } else if (errorMessage.contains("badly formatted")) {
            usernameEditText.setError("Invalid email format.");
        } else if (errorMessage.contains("network error")) {
            Toast.makeText(this, "Network error. Check your internet connection.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Sign up failed: " + errorMessage, Toast.LENGTH_LONG).show();
        }
    }

    // Input validation
    private boolean isValidInput(String email, String password, String name) {
        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            usernameEditText.setError("Enter a valid email");
            return false;
        }
        if (password.isEmpty() || password.length() < 8) {
            passwordEditText.setError("Password must be at least 8 characters");
            return false;
        }
        if (name.isEmpty()) {
            nameEditText.setError("Enter your name");
            return false;
        }

        return true;
    }
}