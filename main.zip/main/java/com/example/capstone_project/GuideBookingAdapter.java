package com.example.capstone_project.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.capstone_project.R;
import com.example.capstone_project.models.BookingModel;

import java.util.ArrayList;

public class GuideBookingAdapter extends RecyclerView.Adapter<GuideBookingAdapter.ViewHolder> {

    private final ArrayList<BookingModel> bookings;
    private final BookingActionListener listener;

    public interface BookingActionListener {
        void onBookingAction(String bookingId, boolean accepted);
    }

    public GuideBookingAdapter(ArrayList<BookingModel> bookings, BookingActionListener listener) {
        this.bookings = bookings;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_guide_booking, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BookingModel booking = bookings.get(position);
        holder.tvUser.setText("User: " + booking.getUserEmail());
        holder.tvDate.setText("Date: " + booking.getDate());
        holder.tvTime.setText("Time: " + booking.getTime());

        holder.btnAccept.setOnClickListener(v -> listener.onBookingAction(booking.getBookingId(), true));
        holder.btnCancel.setOnClickListener(v -> listener.onBookingAction(booking.getBookingId(), false));
    }

    @Override
    public int getItemCount() {
        return bookings.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvUser, tvDate, tvTime;
        Button btnAccept, btnCancel;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvUser = itemView.findViewById(R.id.tvUser);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvTime = itemView.findViewById(R.id.tvTime);
            btnAccept = itemView.findViewById(R.id.btnAccept);
            btnCancel = itemView.findViewById(R.id.btnCancel);
        }
    }
}

