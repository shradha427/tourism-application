package com.example.capstone_project.models;

public class BookingModel {

    private String bookingId;
    private String guideEmail;
    private String userEmail;
    private String date;
    private String time;
    private String status;

    // Default constructor for Firebase
    public BookingModel() {}

    // Constructor with parameters
    public BookingModel(String bookingId, String guideEmail, String userEmail, String date, String time, String status) {
        this.bookingId = bookingId;
        this.guideEmail = guideEmail;
        this.userEmail = userEmail;
        this.date = date;
        this.time = time;
        this.status = status;
    }

    // Getters and setters
    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    public String getGuideEmail() {
        return guideEmail;
    }

    public void setGuideEmail(String guideEmail) {
        this.guideEmail = guideEmail;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    private String feedback;

    public String getFeedback() {
        return feedback;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }
    private String message; // add this field

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
