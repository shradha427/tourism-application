package com.example.capstone_project.models;

public class Feedback {
    private String feedback;
    private String userId;

    public Feedback() {} // Needed for Firestore

    public Feedback(String feedback, String userId) {
        this.feedback = feedback;
        this.userId = userId;
    }

    public String getFeedback() {
        return feedback;
    }

    public String getUserId() {
        return userId;
    }
}
