package com.example.capstone_project.models;

public class GuideModel {
    private String email;
    private String phone;
    private String location;

    public GuideModel() {
        // Default constructor required for Firebase
    }

    public GuideModel(String email, String phone, String location) {
        this.email = email;
        this.phone = phone;
        this.location = location;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getLocation() {
        return location;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
