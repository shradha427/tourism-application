package com.example.capstone_project;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.*;
import com.google.firebase.storage.*;

import java.util.HashMap;
import java.util.Map;

public class UserProfileActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 101;

    private EditText nameEditText, emailEditText, phoneEditText;
    private Button updateButton;
    private ImageView profileImageView;

    private FirebaseAuth auth;
    private FirebaseFirestore firestore;
    private FirebaseStorage storage;

    private String userId;
    private Uri imageUri; // selected image
    private Button feedbackButton, sendFeedbackButton;
    private EditText feedbackEditText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        nameEditText = findViewById(R.id.nameEditText);
        emailEditText = findViewById(R.id.emailEditText);
        phoneEditText = findViewById(R.id.phoneEditText);
        updateButton = findViewById(R.id.updateButton);
        profileImageView = findViewById(R.id.profileImageView);
        feedbackButton = findViewById(R.id.feedbackButton);
        feedbackButton = findViewById(R.id.feedbackButton);
        sendFeedbackButton = findViewById(R.id.sendFeedbackButton);
        feedbackEditText = findViewById(R.id.feedbackEditText);
        auth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();

        FirebaseUser user = auth.getCurrentUser();
        if (user != null) {
            userId = user.getUid();
            loadUserProfile();
        }

        profileImageView.setOnClickListener(v -> chooseImage());

        updateButton.setOnClickListener(v -> updateUserProfile());
    }

    private void chooseImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            profileImageView.setImageURI(imageUri);  // Preview image
        }
    }

    private void loadUserProfile() {
        firestore.collection("Users").document(userId)
                .get().addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        nameEditText.setText(doc.getString("name"));
                        emailEditText.setText(doc.getString("email"));
                        phoneEditText.setText(doc.getString("phone"));

                        String imageUrl = doc.getString("profileImageUrl");
                        if (imageUrl != null && !imageUrl.isEmpty()) {
                            Glide.with(this).load(imageUrl).into(profileImageView);
                        }
                    }
                });
        feedbackButton.setOnClickListener(v -> {
            feedbackEditText.setVisibility(View.VISIBLE);
            sendFeedbackButton.setVisibility(View.VISIBLE);
        });

        sendFeedbackButton.setOnClickListener(v -> {
            String feedback = feedbackEditText.getText().toString().trim();
            if (!feedback.isEmpty()) {
                Map<String, Object> feedbackMap = new HashMap<>();
                feedbackMap.put("userId", userId);
                feedbackMap.put("feedback", feedback);
                feedbackMap.put("timestamp", FieldValue.serverTimestamp());

                firestore.collection("Feedbacks").add(feedbackMap)
                        .addOnSuccessListener(doc -> {
                            Toast.makeText(this, "Feedback sent!", Toast.LENGTH_SHORT).show();
                            feedbackEditText.setText("");
                            feedbackEditText.setVisibility(View.GONE);
                            sendFeedbackButton.setVisibility(View.GONE);
                        })
                        .addOnFailureListener(e -> Toast.makeText(this, "Failed to send feedback", Toast.LENGTH_SHORT).show());
            } else {
                Toast.makeText(this, "Please write something", Toast.LENGTH_SHORT).show();
            }
        });


    }

    private void updateUserProfile() {
        String name = nameEditText.getText().toString().trim();
        String phone = phoneEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();

        FirebaseUser firebaseUser = auth.getCurrentUser();
        if (firebaseUser != null && !email.equals(firebaseUser.getEmail())) {
            firebaseUser.updateEmail(email);
        }

        Map<String, Object> updates = new HashMap<>();
        updates.put("name", name);
        updates.put("phone", phone);
        updates.put("email", email);

        if (imageUri != null) {
            // Upload image first
            StorageReference ref = storage.getReference("ProfileImages").child(userId + ".jpg");
            ref.putFile(imageUri)
                    .addOnSuccessListener(taskSnapshot -> ref.getDownloadUrl().addOnSuccessListener(uri -> {
                        updates.put("profileImageUrl", uri.toString());
                        saveToFirestore(updates);
                    }))
                    .addOnFailureListener(e -> Toast.makeText(this, "Image upload failed", Toast.LENGTH_SHORT).show());
        } else {
            saveToFirestore(updates);
        }
    }

    private void saveToFirestore(Map<String, Object> updates) {
        firestore.collection("Users").document(userId)
                .update(updates)
                .addOnSuccessListener(unused -> Toast.makeText(this, "Profile Updated!", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e -> Toast.makeText(this, "Update Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }


}
